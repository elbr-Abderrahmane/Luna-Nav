# LUNA NAV — Personne 2 : Terrain & données géospatiales

Ce dossier est un **starter kit** pour le rôle Personne 2, adapté au document
« LunaNav vs official challenge: team gap analysis » (14 novembre 2026).

## Mission prioritaire

1. Préparer un catalogue de sites lunaires (`data/sites.json`).
2. Charger les DEM (modèles numériques d'élévation).
3. Extraire le relief autour d'un site (heightmap).
4. Calculer un profil d'horizon par azimut (`horizon.py`).
5. Conserver pente et rugosité comme informations secondaires.

Le profil d'horizon est particulièrement important : Personne 3 calcule la position
du Soleil et de la Terre. Personne 2 fournit l'angle de l'horizon local dans chaque
direction. L'application peut ensuite comparer la hauteur apparente de l'astre à
celle du relief pour savoir s'il est masqué.

## Arborescence

```text
LUNANAV_P2_Terrain/
├── terrain/
│   ├── __init__.py
│   ├── config.py
│   ├── data_loader.py
│   ├── coordinates.py
│   ├── site_catalog.py
│   ├── horizon.py
│   ├── heightmap.py
│   ├── slope.py
│   ├── roughness.py
│   └── geometry_utils.py
├── data/
│   ├── dem/
│   ├── processed/
│   └── sites.json
├── tests/
│   ├── test_coordinates.py
│   ├── test_horizon.py
│   └── test_site_catalog.py
├── requirements.txt
└── README.md
```

## Installation sous Windows / PowerShell

Depuis le dossier du projet :

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Si PowerShell bloque l'activation, exécuter temporairement :

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
```

## Ajouter le DEM

Place le vrai fichier raster dans `data/dem/`, par exemple :

```text
data/dem/lunar_dem.tif
```

Puis configure son chemin dans `terrain/config.py` ou utilise l'argument `dem_path`
des fonctions.

**Important :** ne renomme pas une page HTML, un ZIP ou un fichier vide en `.tif`.
Le fichier doit être un vrai raster lisible par Rasterio. Vérifie aussi sa résolution,
son CRS, ses unités et son système de coordonnées lunaire avant toute interprétation.

## Exemple de calcul d'horizon

Depuis la racine du projet :

```powershell
python -c "import rasterio; print(rasterio.__version__)"
python -m pytest
```

Exemple Python (à adapter aux coordonnées pixel réelles du site) :

```python
from terrain.data_loader import load_dem
from terrain.horizon import calculate_horizon

dem, metadata = load_dem("data/dem/lunar_dem.tif")

profile = calculate_horizon(
    dem=dem,
    observer_row=150,
    observer_col=150,
    pixel_size_x=metadata["pixel_size_x"],
    pixel_size_y=metadata["pixel_size_y"],
    max_distance_m=5000
)

print(profile)
```

`observer_row` et `observer_col` sont des indices de pixel, pas des latitude/longitude.
Il faut d'abord convertir les coordonnées du site en coordonnées raster avec
`terrain.coordinates.world_to_pixel()`.

## Convention du profil d'horizon

Le résultat est une liste de directions :
- `azimuth_deg` : azimut en degrés, mesuré depuis le Nord dans le sens horaire.
- `horizon_elevation_deg` : angle apparent du point de terrain le plus haut observé
  dans cette direction.
- `distance_m` : distance au point qui définit cet angle.

La fonction utilise une méthode simple de ray-marching sur le raster. C'est une
première version pédagogique, pas encore un algorithme scientifique certifié.
Elle suppose que les dimensions de pixel sont en mètres et que le raster est dans
un système projeté local adapté. Ne l'utilise pas directement avec des coordonnées
terrestres ou un CRS lunaire non vérifié.

## Limites scientifiques à traiter avec l'équipe

- Le DEM doit couvrir le terrain autour du site sur une distance suffisante.
- Les coordonnées et le référentiel lunaire doivent être vérifiés à partir de sources fiables.
- Le relief seul ne donne pas les positions du Soleil ou de la Terre : cela relève de Personne 3.
- Le profil d'horizon dépend de l'emplacement de l'observateur, de la résolution du DEM,
  de la distance d'analyse et de la méthode d'échantillonnage.
- Les boulders ou petits obstacles ne sont pas nécessairement visibles dans un DEM
  de résolution grossière.
- Les fonctions pente/rugosité fournies ici sont des indicateurs simples et doivent
  être validées selon les données et critères retenus par l'équipe.
- Le catalogue `sites.json` est laissé vide volontairement : les coordonnées des sites
  doivent être vérifiées et sourcées avant de les ajouter.

## Contrat proposé pour Personne 5

- `load_sites()` retourne une liste de dictionnaires.
- `load_dem()` retourne `(numpy_array, metadata)`.
- `calculate_horizon()` retourne une liste de profils sérialisables en JSON.
- `extract_heightmap()` retourne une grille et ses métadonnées.
- `calculate_slope()` et `calculate_roughness()` retournent des tableaux NumPy.

Les résultats de calcul doivent être convertis en types Python natifs avant d'être
envoyés dans une réponse JSON (par exemple `float(value)`).

## Lancer les tests

À la racine :

```powershell
python -m pytest -q
```
