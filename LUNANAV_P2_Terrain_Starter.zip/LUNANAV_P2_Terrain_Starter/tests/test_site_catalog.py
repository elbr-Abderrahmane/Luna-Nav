import json
from terrain.site_catalog import load_sites


def test_empty_catalog_is_valid(tmp_path):
    path = tmp_path / "sites.json"
    path.write_text("[]", encoding="utf-8")
    assert load_sites(path) == []


def test_catalog_loads_valid_site(tmp_path):
    path = tmp_path / "sites.json"
    site = {
        "id": "EXAMPLE_01",
        "name": "Example site",
        "mission": "Example mission",
        "country_or_agency": "Example agency",
        "status": "past",
        "latitude": 0.0,
        "longitude": 0.0,
        "source": "https://example.org/source"
    }
    path.write_text(json.dumps([site]), encoding="utf-8")
    assert load_sites(path)[0]["id"] == "EXAMPLE_01"
