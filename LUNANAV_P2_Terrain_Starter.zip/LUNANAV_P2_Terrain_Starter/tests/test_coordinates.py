import pytest

rasterio = pytest.importorskip("rasterio")
from rasterio.transform import from_origin
from terrain.coordinates import world_to_pixel, pixel_to_world


def test_world_pixel_round_trip_center():
    transform = from_origin(100, 200, 10, 10)
    x, y = pixel_to_world(transform, 2, 3)
    row, col = world_to_pixel(transform, x, y)
    assert (row, col) == (2, 3)
