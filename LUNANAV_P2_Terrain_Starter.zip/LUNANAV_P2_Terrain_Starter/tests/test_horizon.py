import numpy as np
from terrain.horizon import calculate_horizon, is_object_visible


def test_flat_dem_has_zero_horizon():
    dem = np.zeros((21, 21), dtype=float)
    profile = calculate_horizon(
        dem, 10, 10, pixel_size_x=10, pixel_size_y=10,
        azimuth_step_deg=90, max_distance_m=50
    )
    assert len(profile) == 4
    assert all(abs(p["horizon_elevation_deg"]) < 1e-9 for p in profile)


def test_hill_creates_positive_horizon_in_east():
    dem = np.zeros((21, 21), dtype=float)
    dem[10, 12] = 10
    profile = calculate_horizon(
        dem, 10, 10, pixel_size_x=10, pixel_size_y=10,
        azimuth_step_deg=90, max_distance_m=50
    )
    east = next(p for p in profile if p["azimuth_deg"] == 90.0)
    assert east["horizon_elevation_deg"] > 0


def test_visibility_comparison():
    profile = [
        {"azimuth_deg": 0.0, "horizon_elevation_deg": 2.0, "distance_m": 10.0}
    ]
    assert is_object_visible(0, 3, profile) is True
    assert is_object_visible(0, 1, profile) is False
