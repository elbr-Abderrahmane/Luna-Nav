"""Configuration centrale du module terrain."""
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
DEM_DIR = DATA_DIR / "dem"
PROCESSED_DIR = DATA_DIR / "processed"
SITES_FILE = DATA_DIR / "sites.json"

DEFAULT_DEM_PATH = DEM_DIR / "lunar_dem.tif"

# Paramètres de départ à adapter à la résolution et au référentiel du DEM.
DEFAULT_AZIMUTH_STEP_DEG = 5.0
DEFAULT_MAX_HORIZON_DISTANCE_M = 5_000.0
DEFAULT_HEIGHTMAP_RADIUS_M = 2_000.0
