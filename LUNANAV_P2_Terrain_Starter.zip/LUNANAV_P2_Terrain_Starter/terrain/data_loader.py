"""Chargement et inspection de DEM avec Rasterio."""
from pathlib import Path
import numpy as np

try:
    import rasterio
except ImportError:  # Permet d'importer le package même avant installation.
    rasterio = None


def load_dem(dem_path):
    """Charge la première bande d'un raster et renvoie (array, metadata).

    Les valeurs NoData sont remplacées par NaN. Les unités et le CRS doivent
    être contrôlés par l'appelant avant les calculs métriques.
    """
    if rasterio is None:
        raise ImportError("Rasterio n'est pas installé. Lance: python -m pip install rasterio")

    path = Path(dem_path)
    if not path.exists():
        raise FileNotFoundError(f"DEM introuvable : {path}")

    with rasterio.open(path) as src:
        band = src.read(1, masked=True)
        dem = np.asarray(band.filled(np.nan), dtype=float)
        transform = src.transform
        metadata = {
            "width": src.width,
            "height": src.height,
            "crs": str(src.crs) if src.crs else None,
            "bounds": tuple(src.bounds),
            "nodata": src.nodata,
            "pixel_size_x": abs(float(transform.a)),
            "pixel_size_y": abs(float(transform.e)),
            "transform": tuple(transform),
            "dtype": str(src.dtypes[0]),
        }

    return dem, metadata


def inspect_dem(dem_path):
    """Retourne les métadonnées principales sans charger toute la bande."""
    if rasterio is None:
        raise ImportError("Rasterio n'est pas installé.")
    with rasterio.open(dem_path) as src:
        return {
            "width": src.width,
            "height": src.height,
            "count": src.count,
            "crs": str(src.crs) if src.crs else None,
            "bounds": tuple(src.bounds),
            "resolution": tuple(abs(v) for v in src.res),
            "nodata": src.nodata,
            "dtypes": tuple(src.dtypes),
        }
