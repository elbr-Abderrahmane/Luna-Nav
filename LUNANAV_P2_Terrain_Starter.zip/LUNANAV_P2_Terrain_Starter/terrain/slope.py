"""Calcul simple de pente à partir d'un DEM."""
import numpy as np


def calculate_slope(dem, pixel_size_x, pixel_size_y):
    """Retourne la pente en degrés, calculée par gradient numérique."""
    dem = np.asarray(dem, dtype=float)
    if dem.ndim != 2:
        raise ValueError("dem doit être un tableau 2D.")
    if pixel_size_x <= 0 or pixel_size_y <= 0:
        raise ValueError("Les tailles de pixels doivent être positives.")

    # np.gradient renvoie les dérivées selon les axes 0 (lignes) et 1 (colonnes).
    dz_dy, dz_dx = np.gradient(dem, pixel_size_y, pixel_size_x)
    slope_rad = np.arctan(np.sqrt(dz_dx ** 2 + dz_dy ** 2))
    return np.degrees(slope_rad)
