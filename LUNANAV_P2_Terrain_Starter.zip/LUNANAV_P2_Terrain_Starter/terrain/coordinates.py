"""Conversions entre coordonnées de carte et indices raster.

Ces fonctions s'appuient sur la transformation affine du raster.
Elles ne réalisent PAS à elles seules une transformation latitude/longitude
terrestre vers un référentiel lunaire : le CRS lunaire doit être correctement
défini et fourni par le jeu de données.
"""
try:
    from rasterio.transform import rowcol, xy
except ImportError:
    rowcol = xy = None


def world_to_pixel(transform, x, y):
    """Convertit des coordonnées cartographiques (x, y) en (row, col)."""
    if rowcol is None:
        raise ImportError("Rasterio est nécessaire pour world_to_pixel().")
    row, col = rowcol(transform, x, y)
    return int(row), int(col)


def pixel_to_world(transform, row, col, offset="center"):
    """Convertit un indice (row, col) en coordonnées cartographiques (x, y)."""
    if xy is None:
        raise ImportError("Rasterio est nécessaire pour pixel_to_world().")
    x, y = xy(transform, row, col, offset=offset)
    return float(x), float(y)
