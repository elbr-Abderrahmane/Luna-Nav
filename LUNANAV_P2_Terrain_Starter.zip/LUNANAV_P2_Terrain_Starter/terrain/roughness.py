"""Indicateur simple de rugosité : écart-type local des altitudes."""
import numpy as np
from scipy.ndimage import generic_filter


def calculate_roughness(dem, window_size=3):
    """Calcule l'écart-type local dans une fenêtre carrée impaire.

    Ce résultat est un proxy de rugosité, pas une mesure officielle de risque.
    Les valeurs NoData (NaN) sont ignorées dans chaque fenêtre.
    """
    dem = np.asarray(dem, dtype=float)
    if dem.ndim != 2:
        raise ValueError("dem doit être un tableau 2D.")
    if window_size < 3 or window_size % 2 == 0:
        raise ValueError("window_size doit être un entier impair >= 3.")

    def nan_std(values):
        valid = values[np.isfinite(values)]
        return float(np.std(valid)) if valid.size else np.nan

    return generic_filter(
        dem, nan_std, size=window_size, mode="nearest"
    )
