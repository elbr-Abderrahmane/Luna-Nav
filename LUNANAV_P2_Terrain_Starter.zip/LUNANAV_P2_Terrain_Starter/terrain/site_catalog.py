"""Lecture et validation du catalogue des sites lunaires."""
import json
from pathlib import Path
from .config import SITES_FILE

REQUIRED_FIELDS = {
    "id", "name", "mission", "country_or_agency",
    "status", "latitude", "longitude", "source"
}


def load_sites(path=SITES_FILE):
    """Charge sites.json et vérifie la structure minimale."""
    path = Path(path)
    with path.open("r", encoding="utf-8") as file:
        sites = json.load(file)

    if not isinstance(sites, list):
        raise ValueError("sites.json doit contenir une liste de sites.")

    seen_ids = set()
    for index, site in enumerate(sites):
        missing = REQUIRED_FIELDS - set(site)
        if missing:
            raise ValueError(f"Site #{index}: champs manquants : {sorted(missing)}")
        if site["id"] in seen_ids:
            raise ValueError(f"Identifiant de site dupliqué : {site['id']}")
        seen_ids.add(site["id"])

        if site["status"] not in {"past", "planned"}:
            raise ValueError(f"Statut invalide pour {site['id']} : {site['status']}")
        if not -90 <= float(site["latitude"]) <= 90:
            raise ValueError(f"Latitude invalide pour {site['id']}")
        if not -180 <= float(site["longitude"]) <= 180:
            raise ValueError(f"Longitude invalide pour {site['id']}")

    return sites


def get_site(site_id, path=SITES_FILE):
    """Recherche un site par identifiant."""
    for site in load_sites(path):
        if site["id"] == site_id:
            return site
    raise KeyError(f"Site inconnu : {site_id}")
