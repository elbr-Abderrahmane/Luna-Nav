"""Calcul pédagogique du profil d'horizon à partir d'un DEM."""
import math
import numpy as np


def calculate_horizon(
    dem,
    observer_row,
    observer_col,
    pixel_size_x,
    pixel_size_y,
    azimuth_step_deg=5.0,
    max_distance_m=5_000.0,
    sample_step_m=None,
):
    """Calcule l'angle d'horizon pour plusieurs azimuts.

    Convention :
      - azimut 0° = Nord, 90° = Est, sens horaire ;
      - angle d'élévation = atan2(différence d'altitude, distance horizontale).

    Hypothèses :
      - DEM dans un repère local projeté ;
      - pixels de dimensions métriques ;
      - terrain sans courbure lunaire appliquée dans cette version ;
      - échantillonnage discret simple.

    Les cellules NoData sont ignorées. Si aucune cellule valide n'est trouvée
    dans une direction, horizon_elevation_deg vaut None.
    """
    dem = np.asarray(dem, dtype=float)
    if dem.ndim != 2:
        raise ValueError("dem doit être un tableau 2D.")
    if not (0 <= observer_row < dem.shape[0] and 0 <= observer_col < dem.shape[1]):
        raise ValueError("La position de l'observateur est hors du DEM.")
    if pixel_size_x <= 0 or pixel_size_y <= 0:
        raise ValueError("Les tailles de pixels doivent être positives.")
    if not 0 < azimuth_step_deg <= 360:
        raise ValueError("azimuth_step_deg doit être compris entre 0 et 360.")
    if max_distance_m <= 0:
        raise ValueError("max_distance_m doit être positif.")

    observer_z = dem[observer_row, observer_col]
    if not np.isfinite(observer_z):
        raise ValueError("L'altitude de l'observateur est NoData.")

    if sample_step_m is None:
        sample_step_m = min(pixel_size_x, pixel_size_y)
    if sample_step_m <= 0:
        raise ValueError("sample_step_m doit être positif.")

    results = []
    azimuths = np.arange(0.0, 360.0, azimuth_step_deg)

    for azimuth in azimuths:
        angle = math.radians(float(azimuth))
        best_angle = -90.0
        best_distance = None

        distances = np.arange(sample_step_m, max_distance_m + sample_step_m, sample_step_m)
        for distance in distances:
            # Azimut depuis le Nord : x vers l'Est, y vers le Nord.
            east_m = math.sin(angle) * distance
            north_m = math.cos(angle) * distance

            col = int(round(observer_col + east_m / pixel_size_x))
            row = int(round(observer_row - north_m / pixel_size_y))

            if row < 0 or row >= dem.shape[0] or col < 0 or col >= dem.shape[1]:
                break

            terrain_z = dem[row, col]
            if not np.isfinite(terrain_z):
                continue

            elevation_angle = math.degrees(
                math.atan2(float(terrain_z - observer_z), float(distance))
            )
            if elevation_angle > best_angle:
                best_angle = elevation_angle
                best_distance = float(distance)

        results.append({
            "azimuth_deg": float(azimuth),
            "horizon_elevation_deg": (
                float(best_angle) if best_distance is not None else None
            ),
            "distance_m": best_distance,
        })

    return results


def is_object_visible(object_azimuth_deg, object_elevation_deg, horizon_profile):
    """Compare l'élévation d'un astre à l'horizon interpolé le plus proche.

    Cette version utilise le secteur d'azimut le plus proche, sans interpolation
    circulaire. Pour un usage final, définir avec P3/P5 la convention précise.
    """
    valid = [p for p in horizon_profile if p["horizon_elevation_deg"] is not None]
    if not valid:
        return None

    nearest = min(
        valid,
        key=lambda p: abs((p["azimuth_deg"] - object_azimuth_deg + 180) % 360 - 180)
    )
    return float(object_elevation_deg) > float(nearest["horizon_elevation_deg"])
