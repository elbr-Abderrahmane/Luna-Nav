"""Extraction d'une fenêtre locale de DEM autour d'un pixel."""
import numpy as np


def extract_heightmap(dem, center_row, center_col, pixel_size_x, pixel_size_y, radius_m):
    """Extrait une fenêtre carrée autour d'un pixel central.

    Retourne (heightmap, metadata). La fenêtre est tronquée aux limites du DEM.
    """
    dem = np.asarray(dem, dtype=float)
    if dem.ndim != 2:
        raise ValueError("dem doit être un tableau 2D.")
    if pixel_size_x <= 0 or pixel_size_y <= 0 or radius_m <= 0:
        raise ValueError("Les dimensions de pixel et radius_m doivent être positives.")

    half_cols = int(np.ceil(radius_m / pixel_size_x))
    half_rows = int(np.ceil(radius_m / pixel_size_y))

    r0 = max(0, center_row - half_rows)
    r1 = min(dem.shape[0], center_row + half_rows + 1)
    c0 = max(0, center_col - half_cols)
    c1 = min(dem.shape[1], center_col + half_cols + 1)

    if not (0 <= center_row < dem.shape[0] and 0 <= center_col < dem.shape[1]):
        raise ValueError("Le centre demandé est hors du DEM.")

    result = dem[r0:r1, c0:c1].copy()
    metadata = {
        "row_start": int(r0),
        "row_end_exclusive": int(r1),
        "col_start": int(c0),
        "col_end_exclusive": int(c1),
        "pixel_size_x_m": float(pixel_size_x),
        "pixel_size_y_m": float(pixel_size_y),
        "radius_requested_m": float(radius_m),
        "shape": [int(result.shape[0]), int(result.shape[1])],
    }
    return result, metadata
