"""Petites fonctions de conversion vers des objets JSON/GeoJSON."""
import numpy as np


def to_native(value):
    """Convertit récursivement les types NumPy en types Python sérialisables."""
    if isinstance(value, dict):
        return {str(k): to_native(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_native(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def point_feature(x, y, properties=None):
    """Construit une Feature GeoJSON Point (coordonnées dans le CRS choisi)."""
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [float(x), float(y)]},
        "properties": to_native(properties or {}),
    }
