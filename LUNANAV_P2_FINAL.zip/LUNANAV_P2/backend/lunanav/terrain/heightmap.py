"""JSON-ready extraction of local DEM heightmaps."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from rasterio.windows import Window

from lunanav.coords import latlon_to_xy, normalize_latlon
from lunanav.terrain.dem import DEMReader, site_coverage


def extract_heightmap(
    lat_deg: float,
    lon_deg: float,
    radius_m: float,
    dem_path: str | Path | None = None,
) -> dict[str, Any]:
    """Extract a clipped square heightmap around a lunar coordinate.

    NoData and out-of-raster cells are returned as JSON nulls.
    """
    radius = float(radius_m)
    if not np.isfinite(radius) or radius <= 0:
        raise ValueError("radius_m must be a finite positive number.")
    lat, lon = normalize_latlon(lat_deg, lon_deg)
    coverage = site_coverage(lat, lon, dem_path)
    if not coverage["raster_coverage"]:
        return {
            "status": coverage["status"], "lat_deg": lat, "lon_deg": lon,
            "radius_m": radius, "rows": 0, "cols": 0, "values_m": [],
        }
    path = Path(dem_path) if dem_path is not None else None
    with DEMReader(path) as reader:
        ds = reader.dataset
        x_m, y_m = latlon_to_xy(lat, lon)
        center = reader.pixel_for_xy(x_m, y_m)
        if center is None:
            return {"status": "outside_raster_bounds", "lat_deg": lat, "lon_deg": lon,
                    "radius_m": radius, "rows": 0, "cols": 0, "values_m": []}
        row, col = center
        res_x = abs(float(ds.transform.a))
        res_y = abs(float(ds.transform.e))
        half_cols = max(1, int(np.ceil(radius / res_x)))
        half_rows = max(1, int(np.ceil(radius / res_y)))
        row0, row1 = max(0, row-half_rows), min(ds.height, row+half_rows+1)
        col0, col1 = max(0, col-half_cols), min(ds.width, col+half_cols+1)
        if row0 >= row1 or col0 >= col1:
            return {"status": "empty_window", "lat_deg": lat, "lon_deg": lon,
                    "radius_m": radius, "rows": 0, "cols": 0, "values_m": []}
        data = ds.read(1, window=Window(col0, row0, col1-col0, row1-row0), masked=True)
        values = []
        for row_values in data:
            values.append([
                None if np.ma.is_masked(v) or not np.isfinite(float(v)) else float(v)
                for v in row_values
            ])
        return {
            "status": "ok", "lat_deg": lat, "lon_deg": lon, "radius_m": radius,
            "rows": int(data.shape[0]), "cols": int(data.shape[1]),
            "resolution_m": {"x_m": res_x, "y_m": res_y},
            "center_pixel": {"row": row, "col": col},
            "window_pixel_bounds": {"row_start": row0, "row_stop": row1,
                                    "col_start": col0, "col_stop": col1},
            "bounds_m": {
                "left_m": float((ds.transform * (col0, row0))[0]),
                "top_m": float((ds.transform * (col0, row0))[1]),
                "right_m": float((ds.transform * (col1, row1))[0]),
                "bottom_m": float((ds.transform * (col1, row1))[1]),
            },
            "values_m": values,
            "nodata_count": int(sum(v is None for line in values for v in line)),
        }
